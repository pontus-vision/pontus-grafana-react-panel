# Pontus Vision Grafana React Panel

This is a simple React Panel for Grafana, which enables Pontus Vision POLE data to be displayed in tables in Grafana

To work with this plugin run:

```
yarn dev
```

or

```
yarn watch
```

This will run linting tools and apply prettier fix.

To build the plugin run:

```
yarn build
```
